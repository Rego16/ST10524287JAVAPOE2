
package RegoPart1;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class Message {

    private String messageID;
    private int messageNumber;
    private String recipient;
    private String messageText;
    private String messageHash;
    private String status;

    private static int totalMessagesSent = 0;

    private static final List<Message> sentMessages =
            new ArrayList<>();

    private static final List<String> storedMessages =
            new ArrayList<>();

    // Default constructor.
    public Message() {
        messageID = generateMessageID();
        status = "Not processed";
    }

    // Constructor for creating a message with details.
    public Message(int messageNumber, String recipient,
            String messageText) {

        this.messageID = generateMessageID();
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.messageText = messageText;
        this.status = "Not processed";
        this.messageHash = createMessageHash();
    }

    // Generates a random 10-digit message ID.
    private String generateMessageID() {

        long number = ThreadLocalRandom.current().nextLong(
                1000000000L, 10000000000L);

        return String.valueOf(number);
    }

    // Checks whether the message ID contains exactly 10 digits.
    public boolean checkMessageID() {
        return messageID != null
                && messageID.matches("\\d{10}");
    }

    // Validates South African cellphone numbers.
    // Accepts international format and local format.
    public boolean checkRecipientCell() {

        if (recipient == null) {
            return false;
        }

        boolean internationalFormat =
                recipient.matches("^\\+27[6-8][0-9]{8}$");

        boolean localFormat =
                recipient.matches("^0[6-8][0-9]{8,9}$");

        return internationalFormat || localFormat;
    }

    // Creates the message hash.
    // Format: first two ID digits:message number:first word + last word.
    public String createMessageHash() {

        if (messageID == null || messageID.length() < 2) {
            return "";
        }

        String firstTwoDigits = messageID.substring(0, 2);
        String firstWord = "";
        String lastWord = "";

        if (messageText != null && !messageText.trim().isEmpty()) {

            String[] words = messageText.trim().split("\\s+");

            firstWord = cleanWord(words[0]);
            lastWord = cleanWord(words[words.length - 1]);

            firstWord = firstWord.toUpperCase();
            lastWord = lastWord.toUpperCase();
        }

        return firstTwoDigits + ":" + messageNumber + ":"
                + firstWord + lastWord;
    }

    // Removes punctuation from the beginning and end of a word.
    private String cleanWord(String word) {
        return word.replaceAll(
                "^[^a-zA-Z0-9]+|[^a-zA-Z0-9]+$", "");
    }

    // Displays the message options.
    public void SentMessage(Scanner input) {

        System.out.println("\nChoose what to do with this message:");
        System.out.println("1. Send Message");
        System.out.println("2. Disregard Message");
        System.out.println("3. Store Message to send later");

        int choice = readInteger(input, "Enter your choice: ");

        while (choice < 1 || choice > 3) {
            System.out.println("Please select 1, 2 or 3.");
            choice = readInteger(input, "Enter your choice: ");
        }

        switch (choice) {

            case 1:
                status = "Sent";
                sentMessages.add(this);
                totalMessagesSent++;

                System.out.println("Message successfully sent.");
                printMessageDetails();
                break;

            case 2:
                status = "Disregarded";
                System.out.println("Message disregarded.");
                break;

            case 3:
                status = "Stored";
                storeMessage();
                break;

            default:
                System.out.println("Invalid option.");
        }
    }

    // Main menu for Part 2.
    public static void startQuickChat(Scanner input) {

        boolean running = true;

        while (running) {

            System.out.println("\n========== QUICKCHAT ==========");
            System.out.println("1. Send Messages");
            System.out.println("2. Show recently sent messages");
            System.out.println("3. Quit");

            int choice = readInteger(input, "Choose an option: ");

            switch (choice) {

                case 1:
                    int numberOfMessages = readInteger(
                            input,
                            "How many messages would you like to enter? ");

                    while (numberOfMessages < 1) {
                        System.out.println(
                                "Please enter a number greater than zero.");

                        numberOfMessages = readInteger(
                                input,
                                "How many messages would you like to enter? ");
                    }

                    sendMessages(input, numberOfMessages);
                    break;

                case 2:
                    System.out.println("Coming Soon.");
                    break;

                case 3:
                    System.out.println("\nThank you for using QuickChat.");
                    System.out.println("Total messages sent: "
                            + returnTotalMessagess());

                    running = false;
                    break;

                default:
                    System.out.println(
                            "Invalid option. Please choose 1, 2 or 3.");
            }
        }
    }

    // Collects and processes the requested number of messages.
    private static void sendMessages(
            Scanner input, int numberOfMessages) {

        for (int i = 1; i <= numberOfMessages; i++) {

            System.out.println("\n--- Message " + i + " of "
                    + numberOfMessages + " ---");

            Message message = new Message();
            message.messageNumber = i;

            System.out.print("Enter recipient cellphone number: ");
            message.recipient = input.nextLine().trim();

            while (!message.checkRecipientCell()) {

                System.out.println(
                        "Invalid cellphone number. Enter a valid "
                        + "South African mobile number.");

                System.out.print("Enter recipient cellphone number: ");
                message.recipient = input.nextLine().trim();
            }

            System.out.println(
                    "Enter your message (maximum 250 characters):");

            message.messageText = input.nextLine();

            while (message.messageText.trim().isEmpty()
                    || message.messageText.length() > 250) {

                if (message.messageText.length() > 250) {
                    System.out.println(
                            "Message exceeds 250 characters.");
                } else {
                    System.out.println("Message cannot be empty.");
                }

                System.out.println("Please enter your message again:");
                message.messageText = input.nextLine();
            }

            message.messageHash = message.createMessageHash();

            System.out.println("\nMessage ID: "
                    + message.messageID);

            System.out.println("Message Hash: "
                    + message.messageHash);

            message.SentMessage(input);
        }
    }

    // Prints all the details of a message.
    public void printMessageDetails() {

        System.out.println("\nMessage Details");
        System.out.println("Message ID: " + messageID);
        System.out.println("Message Number: " + messageNumber);
        System.out.println("Recipient: " + recipient);
        System.out.println("Message: " + messageText);
        System.out.println("Message Hash: " + messageHash);
        System.out.println("Status: " + status);
    }

    // Prints all messages sent during this program session.
    public static void printMessages() {

        if (sentMessages.isEmpty()) {
            System.out.println("No messages have been sent.");
            return;
        }

        System.out.println("\n========== SENT MESSAGES ==========");

        for (Message message : sentMessages) {
            message.printMessageDetails();
        }
    }

    // Returns the total number of messages sent.
    public static int returnTotalMessages() {
        return totalMessagesSent;
    }

    // Method name retained for compatibility with the POE spelling.
    public static int returnTotalMessagess() {
        return totalMessagesSent;
    }

    // Stores a message as JSON.
    public void storeMessage() {

        String jsonMessage = "{"
                + "\"messageID\":\"" + escapeJson(messageID) + "\","
                + "\"messageNumber\":" + messageNumber + ","
                + "\"recipient\":\"" + escapeJson(recipient) + "\","
                + "\"messageText\":\"" + escapeJson(messageText) + "\","
                + "\"messageHash\":\"" + escapeJson(messageHash) + "\","
                + "\"status\":\"" + escapeJson(status) + "\""
                + "}";

        storedMessages.add(jsonMessage);

        try (FileWriter writer = new FileWriter("messages.json")) {

            writer.write("[\n");

            for (int i = 0; i < storedMessages.size(); i++) {

                writer.write("  " + storedMessages.get(i));

                if (i < storedMessages.size() - 1) {
                    writer.write(",");
                }

                writer.write("\n");
            }

            writer.write("]");

            System.out.println(
                    "Message successfully stored in messages.json.");

        } catch (IOException e) {

            System.out.println(
                    "Error storing message: " + e.getMessage());
        }
    }

    // Escapes special characters to maintain valid JSON.
    private String escapeJson(String value) {

        if (value == null) {
            return "";
        }

        return value.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    // Reads an integer safely from the console.
    private static int readInteger(Scanner input, String prompt) {

        while (true) {

            System.out.print(prompt);
            String value = input.nextLine().trim();

            try {
                return Integer.parseInt(value);
            } catch (NumberFormatException e) {
                System.out.println(
                        "Invalid input. Please enter a whole number.");
            }
        }
    }

    // Getters for testing and accessing message details.
    public String getMessageID() {
        return messageID;
    }

    public int getMessageNumber() {
        return messageNumber;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessageText() {
        return messageText;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public String getStatus() {
        return status;
    }
}
